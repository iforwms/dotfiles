Please read [Code of Conduct for H5BP](https://github.com/h5bp/html5-boilerplate/blob/master/.github/CODE_OF_CONDUCT.md)
